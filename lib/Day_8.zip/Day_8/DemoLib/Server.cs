﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoLib
{
    public class Server
    {
        private Ping[] pings;
        public Server()
        {
            pings = new Ping[1000];
        }

        public void Ping()
        {
            for (int i = 0; i < pings.Length; i++)
            {
                pings[i] = new Ping();
                pings[i].GetTime();
            }
        }
    }
}

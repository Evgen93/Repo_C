﻿using System;
using DemoLib;

namespace DemoNameSpace
{
    public static class Extentions
    {
        public static void ShowInfo(this Server server, int count)
        {
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine("Ping//");
                server.Ping();
            }
        }
    }
}

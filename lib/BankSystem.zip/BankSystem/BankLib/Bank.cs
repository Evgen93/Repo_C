﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankLib
{
    public class Bank
    {
        private string _name;

        public string Name
        {
            get { return _name; }
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentNullException("Name is not correct...");
                }
                _name = value;
            }
        }

        private const int COUNT_CLIENTS = 10;
        public Bank(string name)
        {
            Name = name;
            _clients = new Client[COUNT_CLIENTS];
        }

        private Client[] _clients;

        public void AddClient(Client client)
        {
            if (client == null)
            {
                throw new ArgumentNullException("client is null");
            }
            _clients[0] = client;
            //todo: реализовать корректный поиск свободного элемента массива
        }

    }
}

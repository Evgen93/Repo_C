﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankLib
{
    public class Client
    {
        private string _LastName;

        public string LastName
        {
            get { return _LastName; }
            set { _LastName = value; }
        }

        private string _firstName;

        public string FirsttName
        {
            get { return _firstName; }
            set { _firstName = value; }
        }

    }
}

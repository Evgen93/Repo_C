﻿using System;
using BankLib;

namespace BankSystem
{
    class Terminal
    {
        public  static Client RegistrationForm()
        {
            Console.Write("Введите имя: ");
            string firstName = Console.ReadLine();

            Console.Write("Введите фамилию: ");
            string lastName = Console.ReadLine();

            return new Client()
            { FirsttName = firstName, LastName = lastName};
        }
       
    }
}

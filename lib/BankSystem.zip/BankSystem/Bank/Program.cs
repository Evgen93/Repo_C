﻿using System;
using BankLib;

namespace BankSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            Bank bank = new Bank("SUPER_IVAN");
            Client client = Terminal.RegistrationForm();
            bank.AddClient(client);

            Console.Read();
        }
    }
}

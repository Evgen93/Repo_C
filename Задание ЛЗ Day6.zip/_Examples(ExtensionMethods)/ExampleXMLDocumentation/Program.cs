﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExampleXMLDocumentation
{
    class MyMath
    {
        static void Main(string[] args)
        {
            double S=MyMath.AreaOfTriangle(4, 3, 5);
            Console.WriteLine("Площадь треугольника: "+S);
            Console.ReadKey();

        }
        /// <summary>
        /// Метод для расчета площади треугольника по формуле Герона
        /// </summary>
        /// <param name="a">Значение стороны а</param>
        /// <param name="b">Значение стороны b</param>
        /// <param name="c">Значение стороны c</param>
        /// <returns>Значение площади треугольника</returns>
        static double AreaOfTriangle(int a, int b, int c)
        {
            double p = (a + b + c) / 2;
            return Math.Sqrt(p*(p-a)*(p-b)*(p-c));
        }
    }

}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// использование расширяющего метода при подключении пространства имен
using AdditionObject;

namespace Example2ExtensionMethod
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 10;
            Console.WriteLine(a.GetInfo());

            string str = "C#";
            Console.WriteLine(str.GetInfo());

            int[] arr = new int[5];
            Console.WriteLine(arr.GetInfo());

            Car car = new Car() { Name="BMW"};
            Console.WriteLine(car.GetInfo());

            Console.Read();
        }
    }

    class Car
    {
        public string Name { get; set; }
    }

}

namespace AdditionObject
{
    public static class AddOnObject
    {
        public static string GetInfo(this object obj)
        {
            return obj.GetType().IsClass ? "Object Is a Class" : "Object Is Not a Class";
        }
    }



}

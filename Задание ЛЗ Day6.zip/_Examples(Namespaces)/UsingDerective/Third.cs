﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MainNameSpace
{
    class Third
    {
        public void Print()
        {
            Console.WriteLine("Класс Third");
        }
    }
}

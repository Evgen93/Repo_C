﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Common
{
    namespace IT
    {
        namespace NameSpaceseExample
        {
            class MyClass
            {
                public void Print()
                {
                    Console.WriteLine("MyClass");
                }
            }
        }
    }
}
